COMO HOSPEDAR ESTA CALCULADORA
================================

Este pacote contém 1 arquivo: index.html
É a calculadora de precificação para serviços em grupo (mentoria/grupos),
completa em HTML + CSS + JavaScript, sem dependências externas.

OPÇÃO MAIS FÁCIL — Netlify Drop (grátis, sem cadastro obrigatório):
1. Acesse https://app.netlify.com/drop
2. Arraste a pasta inteira (ou o arquivo index.html) para a página
3. Em segundos você recebe um link público
4. Esse link pode ser incorporado no Google Sites via
   Inserir > Incorporar > cole a URL

OPÇÃO GitHub Pages (grátis, precisa de conta GitHub):
1. Crie um repositório novo no GitHub
2. Suba o arquivo index.html pra raiz do repositório
3. Settings > Pages > Source > selecione a branch main
4. O site fica disponível em https://seu-usuario.github.io/repositorio/

PARA SÓ COPIAR E COLAR NO GOOGLE SITES:
Abra o index.html num editor de texto, selecione tudo (Ctrl+A),
copie (Ctrl+C) e cole no campo "Incorporar código" do Google Sites.
