COMO HOSPEDAR ESTA CALCULADORA
================================

Este pacote contém 1 arquivo: index.html
Ele já é a calculadora completa (HTML + CSS + JavaScript num único arquivo,
sem dependências externas).

OPÇÃO MAIS FÁCIL — Netlify Drop (grátis, sem cadastro obrigatório):
1. Acesse https://app.netlify.com/drop
2. Arraste a PASTA "hospedagem-sessao" (ou o arquivo index.html) para a página
3. Em segundos você recebe um link público (ex: nome-aleatorio.netlify.app)
4. Esse link pode ser usado direto, ou incorporado no Google Sites via
   Inserir > Incorporar > cole a URL

OPÇÃO GitHub Pages (grátis, precisa de conta GitHub):
1. Crie um repositório novo no GitHub
2. Suba o arquivo index.html pra raiz do repositório
3. Vá em Settings > Pages > Source > selecione a branch main
4. Em alguns minutos o site fica disponível em
   https://seu-usuario.github.io/nome-do-repositorio/

OPÇÃO Google Drive (mais simples, mas menos confiável para embed):
1. Suba o index.html pro Google Drive
2. Clique com botão direito > Compartilhar > Qualquer pessoa com o link
3. Use um serviço como https://www.googledrive.com/host/ (descontinuado)
   — por isso Netlify ou GitHub Pages são mais recomendados

DEPOIS DE HOSPEDAR:
No Google Sites, vá em Inserir > Incorporar > cole a URL do site publicado
(não precisa colar código, só a URL). Ajuste a altura do bloco para uns
900-1100px para não cortar a calculadora.
